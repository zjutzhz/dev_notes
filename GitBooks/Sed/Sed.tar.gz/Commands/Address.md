# address

## 位置语法
|指令|含义|
|------|------|
|n|第n行，从1开始|
|$|最后一行|
|m,n|从第m行到n行|
|m,+n|从第m行开始取n行|
|m～n|从第m行开始，每n行取一行|
|/pattern/|匹配pattern的那一行|
|/pattern/，$|匹配pattern的那一行|
|/pattern1/，/pattern2/|匹配pattern1的那一行到匹配pattern2的那一行|
