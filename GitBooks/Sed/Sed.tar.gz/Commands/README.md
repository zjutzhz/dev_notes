# 指令

sed拥有丰富的指令完成文本处理操作

准备实验文本

```
**[terminal]
**[prompt zheng@hz]**[path ~]**[delimiter $ ]**[command cat book.txt]
1) A Storm of Swords, George R. R. Martin, 1216
2) The Two Towers, J. R. R. Tolkien, 352
3) The Alchemist, Paulo Coelho, 197
4) The Fellowship of the Ring, J. R. R. Tolkien, 432
5) The Pilgrimage, Paulo Coelho, 288
6) A Game of Thrones, George R. R. Martin, 864
```
