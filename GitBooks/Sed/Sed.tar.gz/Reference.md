# 参考资料

1. [Sed Tutorial](https://www.tutorialspoint.com/sed/index.htm)
2. [sed命令](http://man.linuxde.net/sed)
