# 处理流程

![img](pics/Sed_workflow.jpg)

## 一般处理分为三步
1. 从输入流里读入
1. 执行Sed指令
1. 输出执行结果
